<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header">
            <div class="logo"><a href="index.php"><img src="admin/assets/images/logo.png" alt=""></a></div>
            <div class="header-btn-container">
                <button class="header-btn" id="login-btn" onclick="window.location.href='login.php'">Log In</button>
                <button class="header-btn" id="signup-btn" onclick="window.location.href='signup.php'">Sign Up</button>
   
            </div>  
        </div>
    </header>
</body>
</html>